<?php
echo("<h2><center> olá povo </h2>");
print("ola<br>");
//este é um comentario simples
/*tbm*/
$nome = "danilo";
$sobrenome = "silva";
$idade = "15";
$numero = "2024";
$diatrab = "22";
$valordia = "85";
$salario = $diatrab * $valordia;
//-----------------------------------------
echo("nome:" . $nome . "<br>");
echo("sobrenome:" . $sobrenome . "<br>");
echo("nome completo:" . $nome . " " . $sobrenome . "<br>");
echo("idade:" . $idade . "<br>");
echo("dias trabalhados no mês:" . $diatrab. "<br>");
echo("valor recebido por dia:" . $valordia . "<br>");
echo("ou seja o seu salario é:" . $diatrab . "X" . $valordia. "=". $salario . "<br>");
//---------------------------------------------------------------------------------------
echo ("<h1>agora vamos mexer com calculos</h1>");
$a = 10;
$b = 20;
$soma;
$subtraçao;
$multiplicacao;
$divisao;
//---------------------------------------------------------------------------------------
$soma = $a + $b;
$subtraçao = $a - $b;
$multiplicacao = $a * $b;
$divisao = $a / $b;
//---------------------------------------------------------------------------------------
echo("soma:".$a."+".$b."=".$soma."<br>");
echo("subtração:".$a."-".$b."=".$subtraçao."<br>");

?>