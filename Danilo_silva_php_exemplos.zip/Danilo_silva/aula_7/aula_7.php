<?php
echo ("hello word");
echo ('<div class="dv1" style="background-color:blue;">vamos brincar de swithcase</div>');
$favoritecolor = 'purple';
switch($favoritecolor){
case "red":
    echo ("your favorite color ir red");
    break;
case "green":
    echo ("your favorite color ir green");
    break;
case "blue":
    echo ("your favorite color ir blue");
    break;
    default:
    echo ("your favorit color is not: blue grenn and red rs :/");
}
?>