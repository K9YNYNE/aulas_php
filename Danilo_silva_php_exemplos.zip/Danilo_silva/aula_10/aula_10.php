<?php 
echo("<h2> laço de repetição for</h2>");
$x = 2;
for ($x =5; $x <= 10; $x++){
    echo("number is: $x <br>");   
} 
echo ("--------------------------------------------------------------------");
echo("<h2> Agora com break</h2>");
for ($x =5; $x <= 10; $x++){
    if ($x == 8) 
    break;
    echo("number is: $x <br>"); 
}
?>