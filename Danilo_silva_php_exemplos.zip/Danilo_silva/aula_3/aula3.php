<?php 
echo "Hello" . "<br>";
echo 'Hello' . '<br>';
echo 'Enrico' . '<br>';
$x = "Enrico";
echo "Hello $x" . '<br>';
echo 'Hello $x' . '<br>';

echo strlen("dandan") . "<br>";

echo str_word_count("Hello world! Enrico Hidalgo a b c d") . "<br>";

echo str_word_count('UOL, a maior empresa brasileira de conteúdo, serviços digitais e tecnologia com vários canais de jornalismo e diversas soluções para você ou seu negócio.') . "<br>";

echo strpos("Hello ou world!", "world!") . "<br>";

echo ("<br>");
//echo... contar letras....
echo strlen("UOL, a maior empresa brasileira de conteúdo, serviços digitais e tecnologia com vários canais de jornalismo e diversas soluções para você ou seu negócio.")
?>
