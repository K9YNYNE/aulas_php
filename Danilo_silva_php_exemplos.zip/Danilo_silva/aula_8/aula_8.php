<?php
echo ("<h1><center>contando ate 10</h1>");
$numer = 0;
while ($numer < 10){
    echo($numer ."+1 =");
    $numer++;
    echo ($numer."<br></center>");
}
echo("-------------------------------------------------<br>");
echo ("<h1>agora ate o 15</h1>");
while ($numer < 20) {
    if ( $numer == 16) break;
    echo ($numer."+ 1 = ");
    $numer++;
    echo(" " . $numer. "<br>");
}
echo("-------------------------------------------------<br>");
?>