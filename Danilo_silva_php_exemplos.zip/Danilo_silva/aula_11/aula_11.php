<?php
echo ("pausar quando  chegar no green:<br>");
$color = array ("red","blue", "yellow", "green");
foreach ($color as $x){
    if ($x == 'green')
    break;
echo ($x. "<br>");
}
?>