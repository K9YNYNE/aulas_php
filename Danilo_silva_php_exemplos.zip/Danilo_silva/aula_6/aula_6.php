<?php
if (5>3){
    echo ('hello word;');
}
echo ("<br>");
if (3 != 5){
    echo ("rsrsr");
}
$y = 32;
echo ('<br>');
if ($y >= 42){
    echo ("have a good ideia");
}
else { 
    echo ("not have a good ideia");
}
$horario = date("H") -3 ;
echo("<br>".$horario . " hrs ");
if ($horario < "12"){
    echo ("bom dia");
} 
elseif($horario < "18") {
    echo ("boa tarde");
} 
else {
  echo ("boa noite");
}
?>