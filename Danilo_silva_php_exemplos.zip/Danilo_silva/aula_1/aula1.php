<?php
   phpinfo(); 
?>